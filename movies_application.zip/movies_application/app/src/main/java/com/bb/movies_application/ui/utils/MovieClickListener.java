package com.bb.movies_application.ui.utils;


import com.bb.movies_application.model.Movie;

@SuppressWarnings("ALL")
public interface MovieClickListener {
    void onMovieClick(Movie movie);

}
