package com.bb.movies_application.ui.utils;


import com.bb.movies_application.model.MovieTrailer;

public interface TrailerClickListener {
    void onMovieTrailerClick(MovieTrailer mMovieTrailer);

}
